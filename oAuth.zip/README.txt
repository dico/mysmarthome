This is the oAuth files.
If you don't have permission to install oAuth on your server, you can copy these file to the web-root of MSH.